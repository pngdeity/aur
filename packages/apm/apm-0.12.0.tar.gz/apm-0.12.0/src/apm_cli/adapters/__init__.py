"""Adapters package."""
