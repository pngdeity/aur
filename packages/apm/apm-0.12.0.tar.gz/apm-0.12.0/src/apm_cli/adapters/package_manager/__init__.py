"""Package manager adapters package."""
